from flask import Flask, request
from flask_restful import Resource, Api
import textwrap
import io
import openpyxl, pprint
import re


app = Flask(__name__)
api = Api(app)


class Matched_KA(Resource):

    def get(self):
        matched_PBI_dict = {}
        la = []
        #result = {"PBIXXX10":"test"+search_string}
        counter = 0

        search_string = request.args.get('searchString').lower()
        so_name = request.args.get('so').lower()
        f = io.open('ServiceOffering.txt', 'r', encoding='utf-8')
        list_So = []
        for line in f:
            filename = re.sub('[!@#$&/]', '', line.strip().lower())
            list_So.append(filename)
        matchedSo = []
        for items in list_So:
            if so_name in items:
                matchedSo.append(items)

        for offering in matchedSo:
            excel_data = openpyxl.load_workbook('C:/Users/proprama/PycharmProjects/Python_tutorial_programiz/KA_BOT/ExcelFiles/'+ offering +'.xlsx')
            page = excel_data.get_sheet_by_name('Sheet1')
            for cell in range(1, page.max_row):
                x = page.cell(row=cell, column=3).value
                y = page.cell(row=cell, column=4).value
                if (x is not None and search_string in x.lower()) or (y is not None and search_string in y.lower()):
                    li = []
                    li.append(page.cell(row=cell, column=1).value)
                    li.append(" || ")
                    li.append(offering)
                    li.append(" || ")
                    li.append(page.cell(row=cell, column=2).value)
                    li.append(" ||  ")
                    li.append(y)
                    li.append(" ||  ")
                    if(x is None):
                        li.append("Meta Tag is empty - Please add!")
                    else:
                        li.append(x)

                    # Appending to the main list
                    la.append("".join(li))
                    #counter += 1
                    #if counter > 9:
                     #   return (la)

        #output_data = (str(la))
        if not la:
            return("Oops,I couldn't strike a match :( Input does not match any PBI Summary/Description, please try again with a different Keyword!")
        #return (output_data.split("||"))
	#la.append([])
        return (la)

        #return json.dumps(matched_PBI_dict,sort_keys=True,indent=4, separators=(',', ': '))


api.add_resource(Matched_KA, '/matchedKA/')
if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port=8090)



