N = int(input())
li = [int(x) for x in input().split()]
x = int(input())
print(li.index(x))