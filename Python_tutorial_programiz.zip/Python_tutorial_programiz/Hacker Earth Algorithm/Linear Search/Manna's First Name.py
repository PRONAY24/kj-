s1 = 'SUVO'
s2 = 'SUVOJIT'
T = int(input())
for i in range(T):
    word = input()
    print('SUVO =',word.count(s1)-word.count(s2),end=", ")
    print('SUVOJIT =',word.count(s2))