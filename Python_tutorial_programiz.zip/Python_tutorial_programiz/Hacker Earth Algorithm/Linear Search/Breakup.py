N = int(input())
no_date = ['1','2','3','4','5','6','7','8','10','9','11','12','13','14','15','16','17','18','21','22','23','24','25','26','27','28','29','30']
c_nin= 0
c_twen = 0
c_oth = 0
for i in range(N):
    word = input()
    st = "".join(word).split(" ")
    for i in st:
        if st[0] == 'G':
            if i == '19':
                c_nin += 2
            elif i == '20':
                c_twen += 2
            elif i in no_date:
                c_oth +=2
        else:
            if i == '19':
                c_nin += 1
            elif i == '20':
                c_twen += 1
            elif i in no_date:
                c_oth += 1
if c_oth == c_twen == c_nin:
    print("No Date")
elif max(c_oth,c_nin,c_twen) == c_twen or max(c_oth,c_nin,c_twen) == c_nin:
    print("Date")
else:
    print("No Date")