N,M = input().split()
N = int(N)
M = int(M)
li = [ int(x) for x in input().split()]
for i in range(N-1,-1,-1):
    if li[i] == M:
        print(i+1)
        break
else:
    print(-1)