T = int(input())
vowels = 'aeiouAEIOU'

for i in range(T):
    count_vowels = 0
    word = input()
    for i in word:
        if i in vowels:
            count_vowels += 1
    print(count_vowels)
