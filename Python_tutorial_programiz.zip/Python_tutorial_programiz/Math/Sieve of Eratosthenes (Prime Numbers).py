def sieve( n ):
    isPrime = []
    for i in range(0,n):
        isPrime.append(True)
    if n > 0:
        isPrime[0] = False
    if n > 1:
        isPrime[1] = False
    #print(len(isPrime))
    i = 2
    while(i*i <= n):
        if isPrime[i] == True:
            j = i
            while j*i < n:
                isPrime[i*j] = False
                j +=1
        i += 1

    print(isPrime.count(True))
    print(isPrime)
n = int(input())
sieve(n)

