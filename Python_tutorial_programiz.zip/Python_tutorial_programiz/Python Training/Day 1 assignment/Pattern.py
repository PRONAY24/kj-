for i in range(10):
    for j in range(i):
        print(i,end="")
    print("",end=" ")