total = 0
y = 0
print(y,end=" ")
x = 1
print(x,end=" ")
while True:
        total = x + y
        if total>50 :
            break
        print(total,end=" ")
        y = x
        x = total