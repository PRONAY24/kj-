for i in range(200,289,2):
    if int(i/10) %2 == 0:
        print(i,end=",")
print(400)