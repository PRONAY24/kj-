s = ["wheniseeyouagain", "borntorun", "nothingelsematters", "cecelia", "boss"]
k = 3
q = "wheniseeyouagain"
n = len(s) - 1
index = (s.index(q))
check = abs(k - index)

if n - k < k:
    # print("step 1")
    check2 = (n - k + s.index(q) + 1)
else:
    # print("step -2")
    chcek2 = (n - s.index(q) + k + 1)

print(min(check, check2))