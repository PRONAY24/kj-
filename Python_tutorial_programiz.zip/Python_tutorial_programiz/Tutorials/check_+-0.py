# Pyhton program to check if the given number is positive, negative or zero.
num = float(input("Enter you number :"))
if num==0:
    print("You Entered Zero")
elif num <0:
    print("You entered negative number")
else:
    print("You entered positive number")