#Program to add two numbers
num1 = input('Enter the first number:')
num2 = input('Enter the second number :')

sum = float(num1)+float(num2)

print('The sum of {} + {} is'.format(num1,num2), sum)