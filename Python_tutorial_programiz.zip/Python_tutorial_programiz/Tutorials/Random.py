#Python program to generate random numbers

#Import the random module
import random

print(random.randint(33,35))