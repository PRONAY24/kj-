#Python program to swap two/three values

#Taking input from user
a = input("Enter the first value :")
b = input("Enter the second value :")
c = input("Enter the third value :")

#Swapping the values
a,b,c =c,b,a

#Printing the values again after swapping
print("After swapping..")
print("First Value, a =",a)
print("Second Value, b =",b)
print("Third Value, c =",c)