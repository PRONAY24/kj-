#Python program for list overlap

list_1 = [2,1,34,5,5,6,7,8,9,0,11,13]
list_2 = [3,2,6,66,7,4,33,4,13,5]
list_3 = []
for i in list_1:
    if i in list_2:
        list_3.append(i)
print(list_3)