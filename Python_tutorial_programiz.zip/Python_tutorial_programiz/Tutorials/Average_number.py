#Pyhton program to get average of given numbers if we enter newline .

print("Please enter your numbers below.")
sum =0
count = 0
while(2):
    num = input()
    if(len(num)==0):
        break
    sum = sum + int(num)
    count+=1
print("Average of all numbers is :",sum/count)