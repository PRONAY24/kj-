# Python program to calculate area of triangle

a=int(input("Enter the value of side a :"))
b=int(input("Enter the value of side b :"))
c=int(input("Enter the value of side c :"))

s = (a + b + c) / 2

area = (s*(s-a)*(s-b)*(s-c))**0.5
print("The area of triangle is %0.2f with perimeter "%area,s)