a = "ABCDDlklksdlk kjskdk "
x = a.strip("ABkj")
print(x)