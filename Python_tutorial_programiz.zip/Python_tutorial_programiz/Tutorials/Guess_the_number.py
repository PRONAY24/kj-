#Python program to Guess the random number
import random

def check_number(x):
    if x.isdigit()== True:
        return True
    else:
        print("This is not a positive number.")
        return False

def check_match(x,y):
    if int(x) == int(y):
        print("Congrats you guessed the right numnber.")
        return
    elif int(x) > int(y):
        print("Your number is greater than dice's number.")
    else:
        print("Your number is smaller than dice's number.")

print("Guess a random number between 1 to 6 before we roll the dice.")
while (5):
    ur_value = input("Your value :")
    if check_number(ur_value)== False:
        break
    random_value = random.randint(1,6)
    print(random_value)
    check_match(ur_value,random_value)
    print("Press Y/y to try again.")
    try_value = input()
    if try_value in ('y','Y'):
        continue
    else:
        break


