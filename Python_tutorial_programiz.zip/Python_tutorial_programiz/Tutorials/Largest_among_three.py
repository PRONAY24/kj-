#Python program to print largest number among the three numbers

#Taking inputs from the user
num1 = int(input("Number 1 :"))
num2 = int(input("Number 2 :"))
num3 = int(input("Number 3 :"))

if num1 > num2 :
    if num1 > num3 :
        print("Value {} is largest.".format(num1))
    else:
        print("Value {} is largest.".format(num3))
else:
    if num2 > num3 :
        print("Value {} is largest.".format(num2))
    else:
        print(" 3rd Value {} is largest.".format(num3))