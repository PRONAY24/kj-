#Python Program to show all the divisors

a,b = input().split()
a = int(a)
b = int(b)
count = 0
for i in range(1,min(a,b)+1):
    if (a%i ==0)& (b%i == 0):
        count+=1
print(count)
print(max(a,b)%min(a,b))