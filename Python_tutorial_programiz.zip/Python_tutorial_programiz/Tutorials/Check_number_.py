#Python program to check whether a number is negative, positive or zero

value = float(input("Enter the value (numbers only) to be checked :"))

#Condtion for checking the value
if value < 0 :
    print("This is the negative value.")
elif value > 0 :
    print("This is positive value.")
else:
    print("Zero Value.!")