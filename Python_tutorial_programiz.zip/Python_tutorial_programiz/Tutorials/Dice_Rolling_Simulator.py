#Pyhton program for dice rolling simmulator
import random

print("Welcome to Rolling dice game!")
while(5):
    print("Do you want to roll the dice?")
    print("Press Y/y for yes else anything for no.")
    value = input()
    if value in ('y','Y'):
        print(random.randint(1,6))
    else:
        break
print("thank you.")