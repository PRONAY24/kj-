'''
5
2 4 4 2 4
1 4 1 6 4
'''
N = int(input())
le = [int(x) for x in input().split()]
time = [int(x) for x in input().split()]
len_max = max(le)
time_max = max(time)
la = []
for i in range(len_max+time_max):
    li = []
    for j in range(N):
        if time[j] <= i <= time[j]+le[j]:
            li.append("A"+str(j))
    la.append(li)

final = [list(i) for i in set(map(tuple, la))]
final.sort()
counter = 0
result = []
for i in range(len(final)):
    flag = 0
    for items in final[-1]:
        if items in result:
            flag = 1
    if flag == 0 :
        result.extend(final[-1])
        counter += 1
        if counter > 2:
            break
    del final[-1]
#print(counter)
print(len(result))

