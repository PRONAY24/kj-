'''
Exploring Data Types
'''
from ast import literal_eval

def get_type(input_data):
    try:
        return type(literal_eval(input_data))
    except (ValueError, SyntaxError):
        # A string, so return str
        return str
var = input()
#print(get_type(var))
if get_type(var) == int:
    print("This input is of type Integer.")
elif get_type(var) == float:
    print("This input is of type Float.")
elif get_type(var) == str:
    print("This input is of type string.")
else:
    print("This is something else.")