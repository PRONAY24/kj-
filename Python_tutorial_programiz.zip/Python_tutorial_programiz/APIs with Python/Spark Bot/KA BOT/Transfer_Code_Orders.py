#select SUB_REF_ID,TRANSFER_CODE,TRANSFER_STATE  from sfl_order_prod_service_items where transfer_state in ('RESERVED')
import cx_Oracle
import xlsxwriter
con = cx_Oracle.connect('SFL', 'Sfl#123#', 'SVSPRD')
cur = con.cursor()
statement1 = """
        select SUB_REF_ID,TRANSFER_CODE,TRANSFER_STATE  from sfl_order_prod_service_items where transfer_state in ('RESERVED')
"""
cur.execute(statement1)

data = cur.fetchall()

#Taking subscription details from Get sub API

import json
import requests

task = {"name":"limitedLicenseUser", "password":"Very.Long.Pwd.ABBIIK.GHDDJ.1234567890.9387472294.Sep09.2018"}
resp = requests.post('https://idbroker.webex.com/idb/token/v2/actions/GetBearerToken/invoke', json=task)

tmpBearerToken = resp.json()["BearerToken"]
head = {'Authorization':'Basic QzgyOGQyNzQ5OTYxOWVmZjFiMTg0ZDk4ZjUwM2I2ZGE2NGMxMDg3MGMzYmNlM2I3ZGM4ZjQ5MjJhNDIzYmEwMjM6NDdkYTE3YWVmMjE0MjQzZDI3OWQ4MmFjMTAxMzBmNGM2YzMwMzcyMjgzMTA2NjczZmEzMjExNjFlODVlNzhiMA==',
        'Content-Type':'application/x-www-form-urlencoded'}

params = {"grant_type":"urn:ietf:params:oauth:grant-type:saml2-bearer",
        "scope":"webex-squared:scheduler_use webexsquare:admin Identity:Organization Identity:Config Identity:SCIM webexsquare:billing CloudMeeting:provision",
        "self_contained_token":"false",
        "assertion":tmpBearerToken }
res= requests.post('https://idbroker.webex.com/idb/oauth2/v1/access_token',
                     data = params,
                     headers= {'Authorization':'Basic QzgyOGQyNzQ5OTYxOWVmZjFiMTg0ZDk4ZjUwM2I2ZGE2NGMxMDg3MGMzYmNlM2I3ZGM4ZjQ5MjJhNDIzYmEwMjM6NDdkYTE3YWVmMjE0MjQzZDI3OWQ4MmFjMTAxMzBmNGM2YzMwMzcyMjgzMTA2NjczZmEzMjExNjFlODVlNzhiMA=='
                              })
api_token = res.json()["access_token"]

headers = {'Content-Type': 'application/json',
           'Authorization': 'Bearer {0}'.format(api_token)}

def get_account_info(subid):

    url = 'https://atlas-a.wbx2.com/admin/api/v1/commerce/orders/search?serviceId='
    order = subid
    api_url = url+order
    response = requests.get(api_url, headers=headers)

    if response.status_code >= 500:
        print('[!] [{0}] Server Error'.format(response.status_code))
        return None
    elif response.status_code == 404:
        #return ('Order Not Found!')
        return None
        #print('[!] [{0}] URL not found: [{1}]'.format(response.status_code, api_url))

    elif response.status_code == 401:
        print('[!] [{0}] Authentication Failed'.format(response.status_code))
        return None
    elif response.status_code == 400:
        print('[!] [{0}] Bad Request'.format(response.status_code))
        return None
    elif response.status_code >= 300:
        print('[!] [{0}] Unexpected Redirect'.format(response.status_code))
        return None
    elif response.status_code == 200:
        ssh_keys = json.loads(response.content.decode('utf-8'))
        return ssh_keys
    else:
        return ('Order Not Found!')
    #return None
Transfer_data = []
for i in data:
    x = []
    value = get_account_info(i[0])
    x.append(i[0])
    x.append(i[1])
    x.append(i[2])
    x.append(value[0]['externalOrderId'])
    x.append(value[0]['orderStatus'])
    #print(i[0],i[1],i[2],value[0]['externalOrderId'],value[0]['orderStatus'])
    Transfer_data.append(x)

#print(Transfer_data)


# Create a workbook and add a worksheet.
workbook = xlsxwriter.Workbook('Transfer_code_details.xlsx')
worksheet = workbook.add_worksheet()
row = 1
col = 0
worksheet.write(0,0,'SUBSCRIPTION')
worksheet.write(0,1,'TRANSFER CODE')
worksheet.write(0,2,'TRANSFER CODE STATUS')
worksheet.write(0,3,'ORDER')
worksheet.write(0,4,'ORDER STATUS')

for i in range(len(Transfer_data)):
    worksheet.write(row, col, Transfer_data[i][0])
    worksheet.write(row, col+1, Transfer_data[i][1])
    worksheet.write(row, col+2, Transfer_data[i][2])
    worksheet.write(row, col+3, Transfer_data[i][3])
    worksheet.write(row, col+4, Transfer_data[i][4])
    row += 1

workbook.close()

print("Done!")
while True:
    x = input("Enter Y/y to exit :")
    if x == 'y' or x == 'Y':
        break
