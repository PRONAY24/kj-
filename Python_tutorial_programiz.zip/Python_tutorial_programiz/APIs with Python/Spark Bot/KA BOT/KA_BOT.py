from flask import Flask, request
from flask_restful import Resource, Api
import textwrap
from json import dumps
import openpyxl, pprint
import json


app = Flask(__name__)
api = Api(app)


class Matched_KA(Resource):

    def get(self):
        matched_PBI_dict = {}
        la = []
        #result = {"PBIXXX10":"test"+search_string}


        search_string = request.args.get('searchString').lower()
        so_name = request.args.get('so').lower()
        excel_data = openpyxl.load_workbook(so_name+'.xlsx')
        page = excel_data.get_sheet_by_name('Sheet1')
        for cell in range(1, page.max_row):
            x = page.cell(row=cell, column=3).value
            y = page.cell(row=cell, column=4).value
            if (x is not None and search_string in x.lower()) or (y is not None and search_string in y.lower()):
                li = []
                li.append(page.cell(row=cell, column=1).value)
                li.append(" || ")
                li.append(page.cell(row=cell, column=2).value)
                li.append(" ||  ")
                li.append(y)
                li.append(" ||  ")
                if(x is None):
                    li.append("Meta Tag is empty - Please add!")
                else:
                    li.append(x)

                #li.append(" || ")
                #print(li)
                #matched_PBI_dict[page.cell(row=cell, column=1).value] = li
                #return json.dumps(li)
                la.append("".join(li))

        output_data = (str(la))
        if not la:
            print("Oops,I couldn't strike a match:( Input does not match any PBI Summary/Description, please try again with a different Keyword!")
        #return (output_data.split("||"))
	#la.append([])
        return (la)

        #return json.dumps(matched_PBI_dict,sort_keys=True,indent=4, separators=(',', ': '))


api.add_resource(Matched_KA, '/matchedKA/')
if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port=8090)



