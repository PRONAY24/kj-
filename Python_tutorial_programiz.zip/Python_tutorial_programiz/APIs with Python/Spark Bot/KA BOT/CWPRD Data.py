from flask import Flask, request
from flask_restful import Resource, Api
import cx_Oracle
import datetime
import json

#AR21956297

app = Flask(__name__)
api = Api(app)

def myconverter(o):
    if isinstance(o, datetime.datetime):
        return o.__str__()

class Matched_TangibleID(Resource):

    def get(self):

        tangibleID = request.args.get('searchString')
        #con = cx_Oracle.connect("CWPRD_RO/webex123@sjdbpr643va.corp.webex.com:15021/CWPRD")
        con = cx_Oracle.connect('CWPRD_RO', 'webex123', 'CWPRD')
        cur = con.cursor()
        statement1 = """

        SELECT  HCA.ACCOUNT_NAME, HCA.ACCOUNT_NUMBER "ORACLE AC#",HP.PARTY_NAME,EX.PAYMENT_SYSTEM_ORDER_NUMBER "MARCHANT ORDER#"
    FROM   APPS.IBY_TRXN_SUMMARIES_ALL  S,
           APPS.IBY_TRXN_CORE  TC,
           APPS.IBY_FNDCPT_TX_EXTENSIONS  EX,
           APPS.IBY_FNDCPT_TX_EXTENSIONS  EX1,
           APPS.AR_CASH_RECEIPTS_ALL  CR,
           APPS.AR_RECEIVABLE_APPLICATIONS_ALL  AAA,
           APPS.RA_CUSTOMER_TRX_ALL  CT,
           APPS.HZ_CUST_ACCOUNTS_ALL  HCA,
           APPS.HZ_PARTIES  HP,
           APPS.FND_LOOKUPS   FL_TRX,
           APPS.FND_LOOKUPS   FL_STATUS
   WHERE    S.TANGIBLEID  IN  ('""" + tangibleID + """')
           AND TC.TRXNMID = S.TRXNMID
           AND NVL (EX.PAYMENT_SYSTEM_ORDER_NUMBER, ' ') = S.TANGIBLEID
           AND NVL (EX.TRXN_REF_NUMBER1, ' ') = 'RECEIPT'
           AND CR.PAYMENT_TRXN_EXTENSION_ID = EX.TRXN_EXTENSION_ID
           AND AAA.APPLICATION_TYPE = 'CASH'
           AND AAA.DISPLAY = 'Y'
           AND AAA.CASH_RECEIPT_ID = CR.CASH_RECEIPT_ID
           AND AAA.APPLIED_CUSTOMER_TRX_ID = CT.CUSTOMER_TRX_ID
           AND NVL (EX1.PAYMENT_SYSTEM_ORDER_NUMBER(+), ' ') = S.TANGIBLEID
           AND EX1.TRXN_REF_NUMBER1(+) IS NULL
           AND HCA.CUST_ACCOUNT_ID = CT.BILL_TO_CUSTOMER_ID
           AND HP.PARTY_ID = HCA.PARTY_ID
           AND FL_TRX.LOOKUP_CODE = S.TRXNTYPEID
           AND FL_TRX.LOOKUP_TYPE = 'IBY_TRXNTYPES'
           AND FL_STATUS.LOOKUP_CODE = S.STATUS
           AND FL_STATUS.LOOKUP_TYPE = 'IBY_TRANSACTION_STATUS'
           AND rownum < 2

        """

        print(statement1)
        cur.execute(statement1)
        data = cur.fetchall()
        la = {}
        x = ['**ACCOUNT_NAMEORACLE**', '**ORACLE AC#**', '**PARTY_NAME**', '**MARCHANT ORDER#**']
        for i in range(len(x)):
            la[x[i]] = data[0][i]
        return (la)

        #return json.dumps(matched_PBI_dict,sort_keys=True,indent=4, separators=(',', ': '))


api.add_resource(Matched_TangibleID, '/TangibleID/')
if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port=8099)



