import requests
import json
import xmltodict
import xlsxwriter
import re


#1.GET SSO Token - ESP API Consumption

url = "https://cloudsso.cisco.com/idp/sts.wst"

payload = "    <soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\r\n    <soap:Header>\r\n    <wsa:Action xmlns:wsa=\"http://www.w3.org/2005/08/addressing\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" wsu:Id=\"iJFJKoU2cJbfDgjZTwrmZKpS8nKM\">http://docs.oasis-open.org/ws-sx/ws-trust/200512/RST/Issue</wsa:Action>\r\n    <wsse:Security xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" soap:mustUnderstand=\"1\">\r\n    <wsse:UsernameToken xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" wsu:Id=\"ijhaEN438vD_gRUQC06Apb8B43nE\">\r\n    <wsse:Username>esp_saasp.gen</wsse:Username>\r\n    <wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\">Cisco!23</wsse:Password>\r\n    </wsse:UsernameToken>\r\n    </wsse:Security>\r\n    </soap:Header>\r\n    <soap:Body xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" wsu:Id=\"iGPI7F3OqQHNY_nNdIi6mxp16eqE\">\r\n    <wst:RequestSecurityToken xmlns:wst=\"http://docs.oasis-open.org/ws-sx/ws-trust/200512/\">\r\n    <wst:TokenType>urn:ietf:params:oauth:grant-type:saml2-bearer</wst:TokenType>\r\n    <wst:RequestType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/Issue</wst:RequestType>\r\n    <wsp:AppliesTo xmlns:wsp=\"http://schemas.xmlsoap.org/ws/2004/09/policy\">\r\n    <wsa:EndpointReference xmlns:wsa=\"http://www.w3.org/2005/08/addressing\">\r\n\r\n    <wsa:Address>https://cisco.service-now.com</wsa:Address>\r\n    </wsa:EndpointReference>\r\n    </wsp:AppliesTo>\r\n\r\n    <wst:Claims/>\r\n    <wst:OnBehalfOf>\r\n    <wsse:SecurityTokenReference xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">\r\n    <wsse:Reference URI=\"#ijhaEN438vD_gRUQC06Apb8B43nE\" ValueType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#UsernameToken\"/>\r\n    </wsse:SecurityTokenReference>\r\n    </wst:OnBehalfOf>\r\n    </wst:RequestSecurityToken>\r\n    </soap:Body>\r\n    </soap:Envelope>"
headers = {
    'Content-Type': "application/json",
    'Cache-Control': "no-cache",
    'Postman-Token': "28d1d4c3-6ef5-4989-8859-2d6ab15ad47a"
    }

response_sso = requests.request("POST", url, data=payload, headers=headers)
xmlString = response_sso.text

#2.Response from SSO to Json, get grant_type & assertion
doc = xmltodict.parse(xmlString)
grant_type = doc['S11:Envelope']['S11:Body']['ns:RequestSecurityTokenResponseCollection']['ns:RequestSecurityTokenResponse']['ns:TokenType']
assertion = doc['S11:Envelope']['S11:Body']['ns:RequestSecurityTokenResponseCollection']['ns:RequestSecurityTokenResponse']['ns:RequestedSecurityToken']['wsse:BinarySecurityToken']['#text']

#3.generate Oauth token
url = "https://cisco.service-now.com/saml_bearer_oauth_token.do"
payload = "grant_type="+grant_type+"&assertion="+assertion

headers = {
    'Content-Type': "application/x-www-form-urlencoded",
    'Cache-Control': "no-cache",
    'Postman-Token': "743c7479-8939-433d-b3fc-a53bd0cd8ae8"
    }

response_bearer = requests.request("POST", url, data=payload, headers=headers)
access_token_string = response_bearer.text

#4.Get the access token
access_token = json.loads(access_token_string)
#print(access_token['access_token'])
access_token_code = access_token['access_token']

#5. Hit PBI end point

url = "https://cisco.service-now.com/api/now/table/kb_knowledge"

f = open('ServiceOffering.txt', 'r')
so_names = f.readlines()
f.close()

#querystring = [{"sysparm_query":"u_service_offering.name=Software & Subscription Reporting"}]

#assignment_group.name=GSE-SUBSCRIPTION-SAAS"}#&assignment_group.name=GSE-SUBSCRIPTION-IBS&assignment_group.name=GSE-SUBSCRIPTION-BI&assignment_group.name=GSE-SUBSCRIPTION-ORACLE&assignment_group.name=GSE-SUBSCRIPTION-SALES"}

#payload = "grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Asaml2-bearer&assertion=PHNhbWw6QXNzZXJ0aW9uIElEPSJ3M2VleVh1WHFHdVJJWWxfenFlM0Q0T0o1LjAiIElzc3VlSW5zdGFudD0iMjAxOC0wNC0wNlQxNTowODoxNy43MTdaIiBWZXJzaW9uPSIyLjAiIHhtbG5zOnNhbWw9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphc3NlcnRpb24iPjxzYW1sOklzc3Vlcj5jbG91ZHNzby5jaXNjby5jb208L3NhbWw6SXNzdWVyPjxkczpTaWduYXR1cmUgeG1sbnM6ZHM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvMDkveG1sZHNpZyMiPgo8ZHM6U2lnbmVkSW5mbz4KPGRzOkNhbm9uaWNhbGl6YXRpb25NZXRob2QgQWxnb3JpdGhtPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzEwL3htbC1leGMtYzE0biMiLz4KPGRzOlNpZ25hdHVyZU1ldGhvZCBBbGdvcml0aG09Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvMDQveG1sZHNpZy1tb3JlI3JzYS1zaGEyNTYiLz4KPGRzOlJlZmVyZW5jZSBVUkk9IiN3M2VleVh1WHFHdVJJWWxfenFlM0Q0T0o1LjAiPgo8ZHM6VHJhbnNmb3Jtcz4KPGRzOlRyYW5zZm9ybSBBbGdvcml0aG09Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvMDkveG1sZHNpZyNlbnZlbG9wZWQtc2lnbmF0dXJlIi8-CjxkczpUcmFuc2Zvcm0gQWxnb3JpdGhtPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzEwL3htbC1leGMtYzE0biMiLz4KPC9kczpUcmFuc2Zvcm1zPgo8ZHM6RGlnZXN0TWV0aG9kIEFsZ29yaXRobT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS8wNC94bWxlbmMjc2hhMjU2Ii8-CjxkczpEaWdlc3RWYWx1ZT5KWGoxWnV2QktRUHE5WDJ1Tld2MmRPUzlwNW8wSlNVeWNxOTBYemQ2RzZjPTwvZHM6RGlnZXN0VmFsdWU-CjwvZHM6UmVmZXJlbmNlPgo8L2RzOlNpZ25lZEluZm8-CjxkczpTaWduYXR1cmVWYWx1ZT4KY2dOeUR4aUdlRUZVMmpaUCs4U2pYcWxrZmwweFpIemhFdG1QN2pIdEhNYy9VYVJFMXMwZno1VTl1TVhBUENNQUZpdXIwcGcrNkN4cgpVQWw3WnZSMFBoWXdvQ3ZZWGprT1VKOHlqSzFrdlN1eitpTnJuYnVWcXI4MVlxdUY0enVHV216eDUzZ28vd1VVL3NxcW5ibVFoMGVoClo4SXhBVnNXOHZKb1NnMFJjclk4clVNYy9zNkxQWUkvUVRkOG9TV1FyQjJzUEtIbWFQWXpPZUpjdHhKOEN3Y21XMzcwaW9UY29rc2sKejJDdGZmVm1hWllGVVZ1SE1kUVFkK2NlRG9waWF6anhJUWZoT0NERWJEL05FUktGemFjV3RCMkFrQlJYQlJZRXNXTEdldURmZmtWcQp1S0RQZ0g5R3Q1aUE5MXkwd1ZyZHh2bS9KYXJyOGI5N2FhTFJtZz09CjwvZHM6U2lnbmF0dXJlVmFsdWU-CjxkczpLZXlJbmZvPgo8ZHM6WDUwOURhdGE-CjxkczpYNTA5Q2VydGlmaWNhdGU-Ck1JSUZLRENDQkJDZ0F3SUJBZ0lRU0FnekhwdTNKR0hhaklFTDczdk81ekFOQmdrcWhraUc5dzBCQVFzRkFEQitNUXN3Q1FZRFZRUUcKRXdKVlV6RWRNQnNHQTFVRUNoTVVVM2x0WVc1MFpXTWdRMjl5Y0c5eVlYUnBiMjR4SHpBZEJnTlZCQXNURmxONWJXRnVkR1ZqSUZSeQpkWE4wSUU1bGRIZHZjbXN4THpBdEJnTlZCQU1USmxONWJXRnVkR1ZqSUVOc1lYTnpJRE1nVTJWamRYSmxJRk5sY25abGNpQkRRU0F0CklFYzBNQjRYRFRFMU1URXdNekF3TURBd01Gb1hEVEU0TVRFd01qSXpOVGsxT1Zvd2VERUxNQWtHQTFVRUJoTUNWVk14RXpBUkJnTlYKQkFnTUNrTmhiR2xtYjNKdWFXRXhFVEFQQmdOVkJBY01DRk5oYmlCS2IzTmxNUll3RkFZRFZRUUtEQTFEYVhOamJ5QlRlWE4wWlcxegpNUXd3Q2dZRFZRUUxEQU5IU1ZNeEd6QVpCZ05WQkFNTUVtTnNiM1ZrYzNOdkxtTnBjMk52TG1OdmJUQ0NBU0l3RFFZSktvWklodmNOCkFRRUJCUUFEZ2dFUEFEQ0NBUW9DZ2dFQkFMd2hMWWlvOU5oQW1ydTF0R205czAxZ0JjdXdpZnRGOTFRMUJFQnVPYkNDSXN6Y3dQVGwKMHMzNmdaWER1ODY2a2ZxQmlzb1hFT3JZWTg0WlJ5RFlEYjBzMmhiMHRvZkpsbEJ4L2hNM3RhSEovSEdZam9wUmMydkM1ODlYZjQ2KwpjQytzNDY1ZmhMTjg0VzZaS3lhUnZ2VWUxaXN1R3dmVkdKMDdRUGVMUWxJTXF0Z3RCNmxReHBUVU14VGdFRHlrMTNndHU2aGNjYnpoCmZ3YUt1bkp2YUpLQUlzUjlPb2lxbWpleExkRG1nbVgxc0NtbU54cnhoUGhqeWZCSHRtMnFTQVFJRXFLazcvOWVVaSs5eFFDZFNMYXMKbEh5ZGFkYlBBejdxbjFRK1U1VUdlZlBxOVB3QmhhYjdkNlZVMVBoaFQ2QS9PVVZ5KzV0dXpFRVhZNUFHNVVzQ0F3RUFBYU9DQWFZdwpnZ0dpTUZ3R0ExVWRFUVJWTUZPQ0UyTnNiM1ZrYzNOdk1TNWphWE5qYnk1amIyMkNFMk5zYjNWa2MzTnZNaTVqYVhOamJ5NWpiMjJDCkUyTnNiM1ZrYzNOdk15NWphWE5qYnk1amIyMkNFbU5zYjNWa2MzTnZMbU5wYzJOdkxtTnZiVEFKQmdOVkhSTUVBakFBTUE0R0ExVWQKRHdFQi93UUVBd0lGb0RBZEJnTlZIU1VFRmpBVUJnZ3JCZ0VGQlFjREFRWUlLd1lCQlFVSEF3SXdZUVlEVlIwZ0JGb3dXREJXQmdabgpnUXdCQWdJd1REQWpCZ2dyQmdFRkJRY0NBUllYYUhSMGNITTZMeTlrTG5ONWJXTmlMbU52YlM5amNITXdKUVlJS3dZQkJRVUhBZ0l3CkdSb1hhSFIwY0hNNkx5OWtMbk41YldOaUxtTnZiUzl5Y0dFd0h3WURWUjBqQkJnd0ZvQVVYMkRQWVpCVjM0UkRGSXBnS3JMMWV2UkQKR084d0t3WURWUjBmQkNRd0lqQWdvQjZnSElZYWFIUjBjRG92TDNOekxuTjViV05pTG1OdmJTOXpjeTVqY213d1Z3WUlLd1lCQlFVSApBUUVFU3pCSk1COEdDQ3NHQVFVRkJ6QUJoaE5vZEhSd09pOHZjM011YzNsdFkyUXVZMjl0TUNZR0NDc0dBUVVGQnpBQ2hocG9kSFJ3Ck9pOHZjM011YzNsdFkySXVZMjl0TDNOekxtTnlkREFOQmdrcWhraUc5dzBCQVFzRkFBT0NBUUVBV29pQS9wR1N5QkJCMU5iNDg0NUQKYTBKRVBFK0FmYUFTd0JoVVB2N0FBWTJyOEtMaUhpU0VET2NhNEhJUjJUdmNndmVOQ2lPd21DTE1LZHJpUnUxWWtLWmRkcFBVMk1abwpSQ1F3ajFpY1piU1k5S2U4ODlUdU16bVFPQVhWc0FESlBqUnh1RGE1NmdGc0N4Y3BOMTdJMFg3ZHFSNHZKaVhCbGRpd0FUM0RLSFhmCkJ6azFIK3l5MVBQdXZCcW9MYlhXclA4cjdUMHpYOEt1b282L3RRTnNENXU2ZXVHMEdmQTdjVk1qZW5LaHpaNU5Ccy9kSEpoTzR5WnYKS1MyMFFvSFhxQmRVelpnM1Q2SitHNVk2dVNtQ0JjYWROalNrYk5STjFWK0NvOTJRek5pdFNBajJQeUhTVnYxZW13TkpIWThVcWljSwozYU5Ebk9pZGRZTHI3Z0s1TUE9PQo8L2RzOlg1MDlDZXJ0aWZpY2F0ZT4KPC9kczpYNTA5RGF0YT4KPC9kczpLZXlJbmZvPgo8L2RzOlNpZ25hdHVyZT48c2FtbDpTdWJqZWN0PjxzYW1sOk5hbWVJRCBGb3JtYXQ9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjEuMTpuYW1laWQtZm9ybWF0OnVuc3BlY2lmaWVkIj5lc3BhcGkuZ2VuPC9zYW1sOk5hbWVJRD48c2FtbDpTdWJqZWN0Q29uZmlybWF0aW9uIE1ldGhvZD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmNtOmJlYXJlciIvPjwvc2FtbDpTdWJqZWN0PjxzYW1sOkNvbmRpdGlvbnMgTm90QmVmb3JlPSIyMDE4LTA0LTA2VDE1OjAzOjE3LjcxN1oiIE5vdE9uT3JBZnRlcj0iMjAxOC0wNC0wNlQxNTozODoxNy43MTdaIj48c2FtbDpBdWRpZW5jZVJlc3RyaWN0aW9uPjxzYW1sOkF1ZGllbmNlPmh0dHBzOi8vY2lzY28uc2VydmljZS1ub3cuY29tPC9zYW1sOkF1ZGllbmNlPjwvc2FtbDpBdWRpZW5jZVJlc3RyaWN0aW9uPjwvc2FtbDpDb25kaXRpb25zPjxzYW1sOkF1dGhuU3RhdGVtZW50IEF1dGhuSW5zdGFudD0iMjAxOC0wNC0wNlQxNTowODoxNy43MTdaIiBTZXNzaW9uSW5kZXg9InczZWV5WHVYcUd1UklZbF96cWUzRDRPSjUuMCI-PHNhbWw6QXV0aG5Db250ZXh0PjxzYW1sOkF1dGhuQ29udGV4dENsYXNzUmVmPnVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphYzpjbGFzc2VzOnVuc3BlY2lmaWVkPC9zYW1sOkF1dGhuQ29udGV4dENsYXNzUmVmPjwvc2FtbDpBdXRobkNvbnRleHQ-PC9zYW1sOkF1dGhuU3RhdGVtZW50Pjwvc2FtbDpBc3NlcnRpb24-"
bearer = "Bearer "+str(access_token_code)
headers = {
    'Content-Type': "application/json",
    'Authorization': bearer,
    'Cache-Control': "no-cache",
    'Postman-Token': "e6061fff-4012-4416-854f-5f191244aa51"
    }

for so_name in so_names:

    queryvalue = "u_service_offering.name="+so_name.strip().lower()
    query = {"sysparm_query": queryvalue}
    response = requests.request("GET", url, data=payload, headers=headers, params=query)

    ka_details = json.loads(response.text)
    print(len(ka_details['result']))

    # Create an new Excel file and add a worksheet.
    #filename = query["sysparm_query"][46:]

    filename = re.sub('[!@#$&/]', '', so_name.strip().lower())
    workbook = xlsxwriter.Workbook(filename+'.xlsx')
    worksheet = workbook.add_worksheet()

    for i in range(len(ka_details['result'])):
        worksheet.write(i,0,(ka_details['result'][i]['number']))
        worksheet.write(i,1,(ka_details['result'][i]['workflow_state']))
        worksheet.write(i,2,(ka_details['result'][i]['meta']))
        worksheet.write(i, 3, (ka_details['result'][i]['short_description']))
        #worksheet.write(i,4,(ka_details['result'][i]['text']))

    workbook.close()
print("Yayy!!.")
