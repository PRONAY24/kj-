from flask import Flask, request
from flask_restful import Resource, Api
import cx_Oracle
import textwrap
from json import dumps
import openpyxl, pprint
import json


app = Flask(__name__)
api = Api(app)

class Matched_TangibleID(Resource):

    def get(self):

        tangibleID = request.args.get('searchString')
        con = cx_Oracle.connect('CWPRD_RO', 'webex123', 'CWPRD')
        cur = con.cursor()
        statement1 = """

        SELECT hca.account_name,
                 hca.account_number "ORACLE AC#",
                 hp.party_name,
                 ex.payment_system_order_number PSON,
                 fl_trx.meaning trans_type,
                 fl_status.meaning trans_status,
                 TO_CHAR (s.creation_date, 'DD-MON-YYYY HH:MI:SS') creation_date,
                 s.amount,
                 cr.receipt_number,
                 ct.trx_number,
                 ct.trx_date,
                 ct.bill_to_customer_id
            FROM apps.iby_trxn_summaries_all s,
                 apps.IBY_TRXN_CORE tc,
                 apps.iby_fndcpt_tx_extensions ex,
                 apps.iby_fndcpt_tx_extensions ex1,
                 apps.AR_CASH_RECEIPTS_ALL cr,
                 apps.ar_receivable_applications_all aaa,
                 apps.RA_CUSTOMER_TRX_ALL ct,
                 apps.hz_cust_accounts_all hca,
                 apps.hz_parties hp,
                 apps.fnd_lookups fl_trx,
                 apps.fnd_lookups fl_status
           WHERE     s.tangibleid = '""" + tangibleID + """'
                 AND tc.trxnmid = s.trxnmid
                 AND NVL (ex.payment_system_order_number, ' ') = s.tangibleid
                 AND NVL (ex.trxn_ref_number1, ' ') = 'RECEIPT'
                 AND cr.payment_trxn_extension_id = ex.trxn_extension_id
                 AND aaa.application_type = 'CASH'
                 AND aaa.display = 'Y'
                 AND aaa.cash_receipt_id = cr.cash_receipt_id
                 AND aaa.applied_customer_trx_id = ct.customer_trx_id
                 AND NVL (ex1.payment_system_order_number(+), ' ') = s.tangibleid
                 AND ex1.trxn_ref_number1(+) IS NULL
                 AND hca.cust_account_id = ct.bill_to_customer_id
                 AND hp.party_id = hca.party_id
                 AND fl_trx.lookup_code = s.trxntypeid
                 AND fl_trx.lookup_type = 'IBY_TRXNTYPES'
                 AND fl_status.lookup_code = s.status
                 AND fl_status.lookup_type = 'IBY_TRANSACTION_STATUS'
        ORDER BY 1 DESC, s.creation_date DESC

        """

        print(statement1)
        cur.execute(statement1)
        data = cur.fetchall()
        print(type(data))
        return json.dumps(str(data))


        #return json.dumps(matched_PBI_dict,sort_keys=True,indent=4, separators=(',', ': '))


api.add_resource(Matched_TangibleID, '/TangibleID/')
if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port=8087)



