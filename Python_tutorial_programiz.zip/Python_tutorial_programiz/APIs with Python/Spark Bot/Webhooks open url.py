import requests, time
r = requests.post('https://requestb.in/v64mptv6?inspect', data={"ts":time.time()})
print(r.status_code)
print(r.content)
