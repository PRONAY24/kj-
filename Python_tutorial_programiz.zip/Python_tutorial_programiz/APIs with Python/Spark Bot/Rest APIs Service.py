from flask import Flask, request
from flask_restful import Resource, Api
from json import dumps
import openpyxl, pprint
import json


app = Flask(__name__)
api = Api(app)
excel_data = openpyxl.load_workbook('C:/Users/proprama/PycharmProjects/Python_tutorial_programiz/APIs with Python/problem.xlsx')

class Matched_PBI(Resource):
    def get(self, search_string):
        matched_PBI_dict = {}

        result = {"PBIXXX10":"test"+search_string}
        page = excel_data.get_sheet_by_name('Page 1')

        problem = search_string.lower()
        for cell in range(1, 133):
            x = page.cell(row=cell, column=2).value
            y = page.cell(row=cell, column=6).value
            if problem in x.lower() or problem in y.lower():
                li = []
                li.append(page.cell(row=cell, column=1).value)
                li.append(page.cell(row=cell, column=3).value)
                li.append(page.cell(row=cell, column=2).value)
                matched_PBI_dict[page.cell(row=cell, column=1).value] = li
                #print(page.cell(row=cell, column=1).value)
                #print(json.dumps(matched_PBI_dict))
        return json.dumps(matched_PBI_dict,sort_keys=True,indent=4, separators=(',', ': '))


api.add_resource(Matched_PBI, '/matchedPBI/<search_string>')
if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port=8089)
