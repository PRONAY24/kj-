import requests

url = "https://api.ciscospark.com/v1/webhooks"

payload = "{\r\n  \"resource\" : \"messages\",\r\n  \"event\" : \"created\",\r\n  \"filter\" : \"roomId=Y2lzY29zcGFyazovL3VzL1JPT00vMWM4MjM5NjAtMTdjNi0xMWU4LTg3NDUtOTU5M2Y2ZTIxNzk4\",\r\n  \"targetUrl\" : \"https://requestb.in/v64mptv6\",\r\n  \"name\" : \"Spark Learning Lab Webhook\"\r\n}"
headers = {
    'Authorization': "Bearer YTg5YmI2N2YtNWQ0OS00NWFhLWFhYTQtNDFhNDg2ZDY4Njg2ZGU3MDI1NjMtN2M5",
    'Content-Type': "application/json",
    'Cache-Control': "no-cache",
    'Postman-Token': "ed5f403f-0e48-137c-104a-1f0413535b92"
    }

response = requests.request("POST", url, data=payload, headers=headers)

print(response.text)