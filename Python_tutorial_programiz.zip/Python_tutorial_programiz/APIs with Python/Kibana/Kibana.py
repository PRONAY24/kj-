import requests, time
r = requests.post('https://requestb.in/1a48x4y1?inspect', data={"ts":time.time()})
print(r.status_code)
print(r.content)