import openpyxl,pprint
data = openpyxl.load_workbook('C:/Users/proprama/PycharmProjects/Python_tutorial_programiz/APIs with Python/problem.xlsx')
#print(type(data))
#print(data.get_sheet_names())
page = data.get_sheet_by_name('Page 1')
print(page.max_row)
#print(page['A1'].value)
while True:

    problem = input("Enter the word in lower case : ")
    for cell in range(1,page.max_row):
        x = page.cell(row=cell, column=2).value
        y = page.cell(row=cell, column=6).value
        if problem in x.lower() or problem in y.lower():
            print(cell, page.cell(row=cell, column=1).value,end=" | ")
            print(page.cell(row=cell, column=3).value,end=" | ")
            print(page.cell(row=cell, column=2).value)
    else:
        print("No more matching words.")
    check = input("Enter y/Y to exit else continue:")
    if check == 'y' or check =='Y':
        break

