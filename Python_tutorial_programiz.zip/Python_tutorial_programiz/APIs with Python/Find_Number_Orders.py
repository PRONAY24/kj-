import json
import requests

task = {"name":"limitedLicenseUser", "password":"Very.Long.Pwd.ABBIIK.GHDDJ.1234567890.9387472294.Aug16.2018" }
resp = requests.post('https://idbroker.webex.com/idb/token/v2/actions/GetBearerToken/invoke', json=task)
#print(resp.json()["BearerToken"])
tmpBearerToken = resp.json()['BearerToken']
head = {'Authorization':'Basic QzgyOGQyNzQ5OTYxOWVmZjFiMTg0ZDk4ZjUwM2I2ZGE2NGMxMDg3MGMzYmNlM2I3ZGM4ZjQ5MjJhNDIzYmEwMjM6NDdkYTE3YWVmMjE0MjQzZDI3OWQ4MmFjMTAxMzBmNGM2YzMwMzcyMjgzMTA2NjczZmEzMjExNjFlODVlNzhiMA==',
        'Content-Type':'application/x-www-form-urlencoded'}

params = {"grant_type":"urn:ietf:params:oauth:grant-type:saml2-bearer",
        "scope":"webex-squared:scheduler_use webexsquare:admin Identity:Organization Identity:Config Identity:SCIM webexsquare:billing CloudMeeting:provision",
        "self_contained_token":"false",
        "assertion":tmpBearerToken }
res= requests.post('https://idbroker.webex.com/idb/oauth2/v1/access_token',
                     data = params,
                     headers= {'Authorization':'Basic QzgyOGQyNzQ5OTYxOWVmZjFiMTg0ZDk4ZjUwM2I2ZGE2NGMxMDg3MGMzYmNlM2I3ZGM4ZjQ5MjJhNDIzYmEwMjM6NDdkYTE3YWVmMjE0MjQzZDI3OWQ4MmFjMTAxMzBmNGM2YzMwMzcyMjgzMTA2NjczZmEzMjExNjFlODVlNzhiMA=='
                              })
#print(res.json()["access_token"])
api_token = res.json()["access_token"]

headers = {'Content-Type': 'application/json',
           'Authorization': 'Bearer {0}'.format(api_token)}

def get_account_info(xorder):

    url = 'https://atlas-a.wbx2.com/admin/api/v1/commerce/orders/search?webOrderId='
    order = xorder
    api_url = url+order
    response = requests.get(api_url, headers=headers)

    if response.status_code >= 500:
        print('[!] [{0}] Server Error'.format(response.status_code))
        return None
    elif response.status_code == 404:
        print('[!] [{0}] URL not found: [{1}]'.format(response.status_code, api_url))
        return None
    elif response.status_code == 401:
        print('[!] [{0}] Authentication Failed'.format(response.status_code))
        return None
    elif response.status_code == 400:
        print('[!] [{0}] Bad Request'.format(response.status_code))
        return None
    elif response.status_code >= 300:
        print('[!] [{0}] Unexpected Redirect'.format(response.status_code))
        return None
    elif response.status_code == 200:
        ssh_keys = json.loads(response.content.decode('utf-8'))
        return ssh_keys
    else:
        print('[?] Unexpected Error: [HTTP {0}]: Content: {1}'.format(response.status_code, response.content))
    return None

n = int(input("Number of orders :"))
order_li = []
status =[]
error = []
print("Enter the list of orders - ")
for i in range(n):

    x = input()
    order_li.append(x)

    account_info = get_account_info(order_li[i])

    if account_info is not None:
        status.append(account_info[0]['orderStatus'])
        if (account_info[0]['orderStatus']) == 'ERROR':
            y = account_info[0]['productProvisionStatus']['serviceStatus']
            z = ''
            for i in range(len(y)):
                if (account_info[0]['productProvisionStatus']['serviceStatus'][i].get('status')) == 'ERROR':
                    z = (account_info[0]['productProvisionStatus']['serviceStatus'][i].get('errorInfo'))
                    #print(z)
                    #error.append(z['description'])
                elif (account_info[0]['productProvisionStatus']['serviceStatus'][i].get('status')) == 'NA':
                    #print(account_info[0]['productProvisionStatus']['serviceStatus'][i].get('errorInfo'))
                    z = (account_info[0]['productProvisionStatus']['serviceStatus'][i].get('errorInfo')['description'])
            error.append(z)
            #error.append(account_info[0]['externalOrderId'],account_info[0]['orderStatus'],z)
        else:
            #print(account_info[0]['externalOrderId'],account_info[0]['orderStatus'],'No Error')
            error.append('No Error.')
    else:
        print('[!] Request Failed')

print("Here's your info: ")
print("Order  :  Status")
for i in range(n):
    print(order_li[i],end=" :")
    print(status[i],end="  :  ")
    print(error[i])

while True:
    x = input("Press y/Y for exit.")
    if x in ['y','Y']:
        break

