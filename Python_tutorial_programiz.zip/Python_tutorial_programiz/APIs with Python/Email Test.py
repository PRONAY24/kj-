import win32com.client


class OutlookLib:
    def __init__(self, settings={}):
        self.settings = settings

    def get_messages(self, user, folder="Inbox", match_field="all", match="all"):
        outlook = win32com.client.Dispatch("Outlook.Application")
        myfolder = outlook.GetNamespace("MAPI").Folders[user]
        inbox = myfolder.Folders[folder]  # Inbox
        for box in inbox.Items:
            print(box.Subject)
            #if box.SenderName == 'Ganesh Kumar Singh -X (ganessin - TATA CONSULTANCY SERVICES LIMITED at Cisco)':
                #print(box.Subject)
        '''        
        if match_field == "all" and match == "all":
            return inbox.Items

        else:
            messages = []
            for msg in inbox.Items:
                try:
                    if match_field == "Sender":
                        if msg.SenderName.find(match) >= 0:
                            messages.append(msg)
                    elif match_field == "Subject":
                        if msg.Subject.find(match) >= 0:
                            messages.append(msg)
                    elif match_field == "Body":
                        if msg.Body.find(match) >= 0:
                            messages.append(msg)
                            # print msg.To
                            # msg.Attachments
                            # a = item.Attachments.Item(i)
                            # a.FileName
                except:
                    pass
            return messages
        '''

    def get_body(self, msg):
        return msg.Body

    def get_subject(self, msg):
        return msg.Subject

    def get_sender(self, msg):
        return msg.SenderName

    def get_recipient(self, msg):
        return msg.To

    def get_attachments(self, msg):
        return msg.Attachments

outlook = OutlookLib()
messages = outlook.get_messages('proprama@cisco.com')
for msg in messages:
    print(msg.Subject)
    print(msg.Body)