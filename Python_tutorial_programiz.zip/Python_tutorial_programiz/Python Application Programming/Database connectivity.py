import sqlite3


#Establishing Database connection
con = sqlite3.connect('C:/Users/proprama/PycharmProjects/Python_tutorial_programiz/HackerEarth/TEST1.db')

# preparing a cursor object

cursor = con.cursor()


# preparing sql statement

sql1 = "INSERT INTO EMPLOYEE VALUES (1, 'Ramesh', 32, '1', 2000.00 );"

sql2 = '''

       CREATE TABLE EMPLOYEE (

       EMPID INT(6) NOT NULL,

       NAME CHAR(20) NOT NULL,

       AGE INT,

       SEX CHAR(1),

       INCOME FLOAT

       )

      '''
# preparing sql statement

sql = '''

       SELECT * FROM EMPLOYEE

      '''
# executing sql statement using try ... except blocks

try:

    cursor.execute(sql)

    #con.commit()

except :

    print("unable to fetch data")



# fetching the records

records = cursor.fetchall()


# Displaying the records

for record in records:

    print(record)



# closing the connection

con.close()