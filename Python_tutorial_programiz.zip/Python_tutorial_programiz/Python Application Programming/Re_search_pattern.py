import re

pattern='for'

text='information'

if re.search(pattern, text):

    print('Yes')
else:
    print("Not found")