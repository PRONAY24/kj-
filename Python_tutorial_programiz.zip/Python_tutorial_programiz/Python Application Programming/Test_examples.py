N,Q = input().split()
N = int(N)
Q = int(Q)
S = [[] for i in range(N)]
lastAnswer = 0
for i in range(Q):
    q,a,b = input().split()
    q = int(q)
    a = int(a)
    b = int(b)
    if q == 1:
        x = (a^lastAnswer)%N
        S[x].append(b)
    elif q == 2:
        x = (a ^ lastAnswer) % N
        lastAnswer = S[x][b%len(S[x])]
        print(lastAnswer)
