import queue

class BinaryTree:
    def __init__(self,value):
        self.value = value
        self.left = None
        self.right = None

    def insert_left(self,value):
        if self.left == None:
            self.left = BinaryTree(value)
        else:
            new_node = BinaryTree(value)
            new_node.left = self.left
            self.left = new_node

    def insert_right(self,value):
        if self.right == None:
            self.right = BinaryTree(value)
        else:
            new_node = BinaryTree(value)
            new_node.right = self.right
            self.right = new_node

    def pre_order(self):
        print(self.value)
        if self.left:
            self.left.pre_order()
        if self.right:
            self.right.pre_order()

    def in_order(self):
        if self.left:
            self.left.in_order()
        print(self.value)
        if self.right:
            self.right.in_order()

    def post_order(self):
        if self.left:
            self.left.post_order()
        if self.right:
            self.right.post_order()
        print(self.value)


    def bfs(self):
        que = queue.Queue()
        que.put(self)

        while  not que.empty():
            current_node = que.get()
            print(current_node.value)

            if current_node.left:
                que.put(current_node.left)

            if current_node.right:
                que.put(current_node.right)


Node1 = BinaryTree(5)
Node1.insert_left(3)
Node1.insert_right(7)
Node1.insert_right(6)
Node1.insert_left(2)
print('DFS')
Node1.in_order()
print('BFS')
Node1.bfs()