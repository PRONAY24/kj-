class BinarySearchTree:
    def __init__(self,value):
        self.value = value
        self.left = None
        self.right = None

    def insert_node(self,value):
        if value <= self.value and self.left:
            self.left.insert_node(value)
        elif value <= self.value:
            self.left = BinarySearchTree(value)
        elif value > self.value and self.right:
            self.right.insert_node(value)
        else:
            self.right = BinarySearchTree(value)

    def find_node(self,value):
        if value < self.value and self.left:
            return self.left.find_node(value)
        if value > self.value and self.right:
            return self.right.find_node(value)
        return self.value == value

    def in_order(self):
        if self.left:
            self.left.in_order()
        print(self.value)
        if self.right:
            self.right.in_order()

    def find_minimum_value(self):
        if self.left:
            return self.left.find_minimum_value()
        else:
            return self.value

    def find_maximum_value(self):
        if self.right:
            return self.right.find_maximum_value()
        else:
            return self.value



bst = BinarySearchTree(15)
bst.insert_node(10)
bst.insert_node(8)
bst.insert_node(12)
bst.insert_node(20)
bst.insert_node(17)
bst.insert_node(25)
bst.insert_node(19)

print(bst.find_node(25))
print(bst.find_node(22))
bst.in_order()
print("Minimum:",bst.find_minimum_value())
print('Maximum:',bst.find_maximum_value())