# Python program to detect loop in the linked list

# Node class
class Node:

    # Constructor to initialize the node object
    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:

    # Function to initialize head
    def __init__(self):
        self.head = None

    # Function to insert a new node at the beginning
    def push(self, new_data):
        new_node = Node(new_data)
        new_node.next = self.head
        self.head = new_node

    # Utility function to prit the linked LinkedList
    def printList(self):
        temp = self.head
        while (temp):
            print(temp.data)
            temp = temp.next

    def detectLoop(self):
        slow_p = self.head
        fast_p = self.head
        while (slow_p and fast_p and fast_p.next):
            slow_p = slow_p.next
            fast_p = fast_p.next.next
            if slow_p == fast_p:
                print("Found Loop")
                return

    def detectCycle(self, head):
        """
        :type head: ListNode
        :rtype: ListNode
        """
        if not head: return
        slow = head
        fast = head
        while fast.next and fast.next.next:
            slow = slow.next
            fast = fast.next.next
            if slow == fast: break
        if not fast.next or not fast.next.next: return
        slow = head
        while slow != fast:
            slow = slow.next
            fast = fast.next
        return slow

    def detectCycle(self, head):
        slow = head
        print(slow.data)
        fast = head
        print(fast.data)
        while fast and fast.next:
            slow = slow.next
            print('slow',slow.data)
            fast = fast.next.next
            print('fast',fast.data)
            if slow == fast:
                print('Both equal ',fast.data,' == ',slow.data)
                slow2 = head
                print(slow2.data)
                print(slow.data)
                while slow != slow2:
                    slow = slow.next
                    slow2 = slow2.next
                    print(slow2.data,'== ==',slow.data)
                print(slow2.data,'== ! ==',slow.data)
                return slow.data


# Driver program for testing
llist = LinkedList()
llist.push(20)
llist.push(4)
llist.push(15)
llist.push(10)
llist.push(22)


# Create a loop for testing
llist.head.next.next.next.next.next = llist.head.next
#llist.printList()
print(llist.detectCycle(llist.head))

# This code is contributed by Nikhil Kumar Singh(nickzuck_007)
