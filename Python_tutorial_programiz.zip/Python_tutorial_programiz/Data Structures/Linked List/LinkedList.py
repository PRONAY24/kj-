# ---------LinkedList---------------

# Node Class

class Node:
    def __init__(self,data=None):
        self.data = data
        self.next = None


# Linkedlist class

class LinkedList:
    def __init__(self):
        self.head = None

    def append(self,new_data):
        new_node = Node(new_data)
        curr = self.head
        if self.head is None:
            self.head = new_node
        else:
            while curr.next:
                curr = curr.next
            curr.next = new_node


    def append_in_Beg(self, new_data):
        new_node = Node(new_data)
        temp = self.head
        self.head = new_node
        new_node.next = temp
        del temp

    def append_in_between(self, pos, new_data):
        if pos < 0 :
            print( "Invalid Position")
            return
        new_node = Node(new_data)
        count = 1
        curr = self.head
        if pos == 0:
            self.head = new_node
            new_node.next = curr
            return
        while curr:
            if pos == count:
                new_node.next = curr.next
                curr.next = new_node
                return
            count += 1
            curr = curr.next



    def print_list(self):
        curr = self.head
        if self.head is None:
            print("List is empty")
            return
        else:
            while True:
                print(curr.data,end='')
                if curr.next is None:
                    break
                print('->',end="")
                curr = curr.next
            print()

    def link_size(self):
        curr = self.head
        count = 0
        if curr is None:
            print("0 size")
            return
        while True:
            count += 1
            if curr.next is None:
                return count
            curr = curr.next

    def search(self,find_data):
        curr = self.head
        count = 0
        while curr:
            count += 1
            if curr.data == find_data:
                print(find_data,'found at position',count)
                return
            curr = curr.next
        else:
            print(find_data,'Not found.')


    def delete_end_node(self):
        curr = self.head
        if curr is None:
            print("No node found.")
            return
        while curr.next:
            temp = curr
            curr = curr.next
        temp.next = None

    def deleteAtPos(self,pos):
        if self.head == None:
            return

            # Store head node
        temp = self.head

        # If head needs to be removed
        if pos == 0:
            self.head = temp.next
            temp = None
            return

        # Find previous node of the node to be deleted
        for i in range(pos - 1):
            temp = temp.next
            if temp is None:
                break

        # If position is more than number of nodes
        if temp is None:
            return
        if temp.next is None:
            return

        # Node temp.next is the node to be deleted
        # store pointer to the next of node to be deleted
        next = temp.next.next

        # Unlink the node from linked list
        temp.next = None

        temp.next = next

    def get(self,pos):
        if pos < 0 :
            return -1
        curr = self.head
        count = 0
        while curr:
            if pos == count:
                return (curr.data)
            curr = curr.next
            count += 1
        return -1

    def addList(self,linkedList):
        curr = self.head
        while curr.next:
            curr = curr.next
        curr.next = linkedList

    def getLen(self, head):
        l = 0
        while head:
            l += 1
            head = head.next
        return l

    def getIntersectionNode(self, headA, headB):
        """
        :type head1, head1: ListNode
        :rtype: ListNode
        """
        a_ptr = headA
        b_ptr = headB
        lenA = self.getLen(headA)
        lenB = self.getLen(headB)

        if lenA > lenB :
            move = lenA - lenB
            while move:
                a_ptr = a_ptr.next
                move -= 1
        else:
            move = lenB - lenA
            while move:
                b_ptr = b_ptr.next
                move -= 1
        while a_ptr:
            if a_ptr == b_ptr:
                return a_ptr.data
            a_ptr = a_ptr.next
            b_ptr = b_ptr.next

    def reverseList(self):
        prev = None
        while self.head:
            curr = self.head
            self.head = self.head.next
            curr.next = prev
            prev = curr
        self.head = prev



    def removeElements(self, val):
        curr = self.head
        temp = curr
        while curr:
            if self.head.data == val:
                self.head = self.head.next
            if curr.data == val:
                temp.next = curr.next
                curr = temp
            temp = curr
            curr = curr.next


    def odd_even(self):
        dummy1 = oddlink = Node(0)
        dummy2 = evenlink = Node(0)
        curr = self.head
        while curr:
            oddlink.next = curr
            oddlink = oddlink.next
            evenlink.next = curr.next
            evenlink = evenlink.next
            curr = curr.next.next if evenlink else None
        oddlink.next = dummy2.next
        return dummy1




    def oddEvenList(self, head):
        dummy1 = odd = Node(0)
        dummy2 = even = Node(0)
        if head == None :
            return head
        if head.next == None:
            return head
        if head.next.next == None:
            return head
        while head:
            odd.next = head
            even.next = head.next
            odd = odd.next
            even = even.next
            head = head.next.next if even else None
        odd.next = dummy2.next
        return dummy1.next


    def palindrome(self):
        before_reverse = []
        curr = self.head
        while curr:
            before_reverse.append(curr.data)
            curr = curr.next
        after_reverse = before_reverse[::-1]
        print(after_reverse == before_reverse)

    def mergeTwoLists(self, head1, head2):
        """
        :type l1: ListNode
        :type l2: ListNode
        :rtype: ListNode
        """
        dummy = curr = Node(0)
        while head1  and head2 :
            if head1.data < head2.data:
                curr.next = head1
                head1 = head1.next
            else:
                curr.next = head2
                head2 = head2.next
            curr = curr.next
        curr.next = head1 or head2
        return dummy.next

# creating node
# John -> Sam -> None
node1 = Node('John')
node2 = Node('Sam')
node3 = Node('hash')
node4 = Node(33)
#Creating link in linked list class

reverse_link = link = LinkedList()
link1 = LinkedList()
link2 = LinkedList()
link.append(1)
link.print_list()
reverse_link.reverseList()
reverse_link.print_list()
link.palindrome()
link.append(5)
link.append(3)
link.print_list()

link.listarray()
