# A sample program to demonstrate unpacking of
# dictionary items using **
def fun(a, b, c):
    print(a, b, c)


# A call with unpacking of dictionary
d = {'a': 2, 'b': 4, 'c': 10}
fun(**d)