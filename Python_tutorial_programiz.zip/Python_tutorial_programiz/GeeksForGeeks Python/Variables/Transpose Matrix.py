a = [(1,2,3),(4,5,6),(7,8,9)]
for row in a:
    print(row)
t_a = zip(*a)
for row in t_a:
    print(row)
