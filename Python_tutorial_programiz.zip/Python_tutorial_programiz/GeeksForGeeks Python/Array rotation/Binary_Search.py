def binarySearch( arr, low, high, key):
    if low > high :
        return -1
    mid = int((high + low)/2)

    if arr[mid]== key:
        return mid
    if key > arr[mid]:
        return binarySearch(arr,mid+1,high,key)
    return binarySearch(arr,low,mid-1,key)

arr = [1,2,3,4,5,6]
key = 5
print(binarySearch(arr,0,len(arr)-1,key))