'''
rotate(arr[], d, n)
  reverse(arr[], 1, d) ;
  reverse(arr[], d + 1, n);
  reverse(arr[], l, n);
'''

'''
#reverse array

arr = [1,2,3,4,5]
start = 0
end = len(arr)-1
while start < end:
    arr[start],arr[end]=arr[end],arr[start]
    start += 1
    end -= 1
print(arr)
'''
arr = [1,2,3,4,5,6,7]
d = 2
n = 7
A = arr[:2]
print(A)
B = arr[2:]
print(B)
A.reverse()
print(A)
#A.extend(B)
B.reverse()
A.extend(B)
print(A)
A.reverse()
print(A)
