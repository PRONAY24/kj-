class Kingdom(object):


    # using dictionary setting emblem for each kingdom
    GoldenCrown = {'Space': 'gorilla', 'Water': 'octopus', 'Land': 'panda', 'Fire': 'dragon', 'Air': 'owl',
                   'Ice': 'mammoth'}

    def __init__(self):
        self.ruler = None
        self.allies = None
        self.lis_of_allies = []

    def display(self):
        print('Who is the ruler of Southeros?')
        print(self.ruler)
        print('Allies of Ruler?')
        print(self.allies)

    def takeInput(self):
        # Taking no. of messages
        n = int(input("No. of input messages : "))

        for i in range(n):
            kingdom, message = input('Input:').split(',')
            message = message.lower()
            animal = self.GoldenCrown.get(kingdom)
            is_animal = True
            if animal:
                for i in animal:

                    # Counting the number of letters in animal emblem and message
                    # if all letters are there then adding kingdom in list_of_allies.
                    if animal.count(i) > message.count(i):
                        is_animal = False
            if is_animal == True and kingdom in self.GoldenCrown.keys():
                self.lis_of_allies.append(kingdom)

    def checkRuler(self):
        # Storing in Allies only if wins >= 3
        check_allies = set(self.lis_of_allies)
        if len(check_allies) > 2:
            self.allies = set(self.lis_of_allies)
            self.ruler = 'King Shan'


sendMessage = Kingdom()
sendMessage.display()
print('Input Messages to kingdoms from King Shan:')
sendMessage.takeInput()
sendMessage.checkRuler()
sendMessage.display()
