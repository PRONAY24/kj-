#Python program to check anagrams
#test_case = int(input())
from collections import Counter
n = [ "abcd", "dcba", "dcba", "abcd", "abcd", "adbc", "dabc", "adcb" ]

x = [["abcd","dcba","dcba","abcd","abcd","adbc","dabc","adcb"]]
la = []
for i in x:
    for j in i:
        y = (n.index(j))
        print(y)
        n[y] = ""


