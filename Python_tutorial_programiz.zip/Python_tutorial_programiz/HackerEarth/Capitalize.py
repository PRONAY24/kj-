x = input()
name = list(x)
for i in range(len(name)):
    if i == 0:
        name[i]=name[i].upper()
    elif name[i] == " ":
        name[i+1]=name[i+1].upper()

x = "".join(name)
print(x)