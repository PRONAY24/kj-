# Two Strings
testCase = int(input())
for i in range(testCase) :
    string1,string2 = input().split(" ")
    #string2 = input().split(" ")
    stringList1 = list(string1)
    stringList2 = list(string2)
    stringList1.sort()
    stringList2.sort()
    if stringList1 == stringList2 :
        print("YES")
    else:
        print("NO")