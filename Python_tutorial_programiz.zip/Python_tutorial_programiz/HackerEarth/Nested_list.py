n = int(input())
students = []
for i in range(n):
    stud = []
    name = input()
    stud.append(name)
    value = float(input())
    stud.append(value)
    students.append(stud)
minimum = min(students,key= lambda x : x[1])
x = minimum[1]
for student in range(len(students)) :
    if x == students[student][1]:
        students[student][1]=50000
mini = min(students,key = lambda x : x[1])
min_value = mini[1]
names =[]
for i in range(len(students)):
    if min_value == students[i][1]:
        names.append(students[i][0])
names.sort()
for i in names :
    print(i)
