array = []
n = int(input())
for i in range(n):
    var = list(input().split())
    if var[0] == 'insert':
        position = int(var[1])
        value = int(var[2])
        array.insert(position, value)
    elif var[0] == 'print':
        print(array)
    elif var[0] == 'remove':
        value = int(var[1])
        array.remove(value)
    elif var[0] == 'append':
        value = int(var[1])
        array.append(value)
    elif var[0] == 'sort':
        array.sort()
    elif var[0] == 'pop':
        array.pop()
    elif var[0] == 'reverse':
        array.reverse()
    else :
        print("Wrong Input")

