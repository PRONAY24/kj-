#Python Program to print prime numbers in a given range

N = int(input())            # N = number of inputs
for num in range(2,N) :
    for j in range(2,num//2+1):
        if num % j == 0 :
            break               # if prime then break
    else :
        print(num,end=" ")        # print prime numbers with spaces
