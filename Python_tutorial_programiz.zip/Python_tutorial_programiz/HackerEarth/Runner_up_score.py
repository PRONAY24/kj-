n = int(input())
array = [int(x) for x in input().split()]
array_max = max(array)
for i in range(n):
    if array_max in array :
        array.remove(array_max)

print(max(array))
