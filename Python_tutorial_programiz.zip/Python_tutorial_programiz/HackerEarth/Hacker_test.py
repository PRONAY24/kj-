n = int(input())
li = []
for i in range(n):
    x = input()
    if 'hydro' in x[:5] and 'ic' in x[-2:]:
        print('non-metal acid')
    elif x[-2:] == 'ic':
        print('polyatomic acid')
    else:
        print("not an acid")
