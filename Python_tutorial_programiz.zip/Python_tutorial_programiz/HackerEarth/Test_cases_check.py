import json

res = [
    {
        "orderStatus": "PROVISIONED",
        "serviceProvisioningId": "56069",
        "orderingTool": "CCW",
        "externalOrderId": "82141827",
        "orderUuid": "88960085-e367-44dc-91f2-39021215f4fd",
        "subscriptionUuid": "25904b32-3220-44ac-a0a4-3f151cf2f7e3",
        "productProvisionStatus": {
            "serviceStatus": [
                {
                    "orderItemUuid": "353dd7f4-6a35-4107-a28c-3698b568ea2d",
                    "offerCode": "MS",
                    "status": "PROVISIONED"
                },
                {
                    "orderItemUuid": "36ccd43b-da36-4e28-b0da-74c3b3725070",
                    "offerCode": "ST",
                    "status": "PROVISIONED"
                },
                {
                    "orderItemUuid": "5b949201-6dd3-4700-8fe6-a04f02939641",
                    "offerCode": "CF",
                    "status": "PROVISIONED"
                },
                {
                    "orderItemUuid": "a7a4bc30-e30f-442b-97a4-36fb74225eee",
                    "offerCode": "TSP",
                    "status": "PROVISIONED"
                },
                {
                    "orderItemUuid": "b853a4db-7e86-45db-b63b-32180793a828",
                    "offerCode": "CMR",
                    "status": "PROVISIONED"
                },
                {
                    "orderItemUuid": "eab6f07a-1d7c-4ab6-a6d1-1b632d7ad615",
                    "offerCode": "EE",
                    "status": "PROVISIONED"
                },
                {
                    "orderItemUuid": "f9ffe013-aaee-4b98-93ad-9aa3bf655eb3",
                    "offerCode": "ST-SPK",
                    "status": "PROVISIONED"
                }
            ]
        },
        "orderReceived": "2017-10-31T07:02:37.280Z",
        "serviceId": "Sub123423",
        "purchaseOrderId": "dabcc2c0-689b-406f-95bb-d69b394f8786",
        "lastProvisioningContact": "dl-attwebexorders@att.com",
        "lastProvisioningEmailTimestamp": "2017-10-31T00:30:18.887Z",
        "lastModified": "2017-11-06T22:08:48.650Z",
        "orderContent": {
            "common": {
                "serviceProvisioningId": "56069",
                "SBPOrderId": "82141827/56069",
                "action": "Modify",
                "orderingTool": "CCW",
                "rtm": "1-tier",
                "customerInfo": {
                    "endCustomerInfo": {
                        "name": "Alight Dev",
                        "adminDetails": {
                            "emailId": "John.lee@alight.com"
                        }
                    },
                    "partnerInfo": {
                        "name": "AT&T Corporation",
                        "adminDetails": {
                            "emailId": "dl-attwebexorders@att.com"
                        },
                        "isManager": True
                    }
                },
                "callbackUrl": "https://api.cisco.com/sbp/prd/sfl"
            },
            "collabServiceInfoCommon": {
                "orgName": "ALIGHT SOLUTIONS",
                "serviceId": "Sub123423",
                "partnerName": "AT&T Corporation",
                "site": [
                    {
                        "siteUrl": "Alightacademypoc.webex.com",
                        "action": "New",
                        "timeZoneId": 7,
                        "primaryLanguage": "en-US",
                        "convertFromTrial": False,
                        "userManagedInSiteAdmin": True
                    }
                ]
            },
            "serviceItems": {
                "conferencing": [
                    {
                        "productName": "WX",
                        "serviceName": "EE",
                        "action": "New",
                        "siteUrl": "Alightacademypoc.webex.com",
                        "attendeeCapacity": 200,
                        "attendeeOverage": False,
                        "licenseVolume": 25,
                        "licenseOverage": False,
                        "licenseModel": "HOSTS"
                    },
                    {
                        "productName": "SQ",
                        "serviceName": "CF",
                        "action": "Modify",
                        "attendeeCapacity": 25,
                        "attendeeOverage": False,
                        "licenseVolume": 25,
                        "licenseOverage": True,
                        "convertFromTrial": True
                    }
                ],
                "messaging": [
                    {
                        "productName": "SQ",
                        "serviceName": "MS",
                        "action": "Modify",
                        "licenseVolume": 25,
                        "licenseOverage": True,
                        "convertFromTrial": True
                    }
                ],
                "storage": [
                    {
                        "productName": "CLOUD",
                        "serviceName": "ST",
                        "action": "Modify",
                        "storageCapacity": 10,
                        "storageOverage": False,
                        "convertFromTrial": True
                    },
                    {
                        "productName": "SQ",
                        "serviceName": "ST-SPK",
                        "action": "New",
                        "storageCapacity": 125,
                        "storageOverage": True
                    }
                ],
                "cmr": [
                    {
                        "cmr": "true",
                        "cmrCapacity": "25",
                        "cmrLicenseVolume": "25",
                        "productName": "WX",
                        "serviceName": "CMR",
                        "action": "New",
                        "siteUrl": "Alightacademypoc.webex.com",
                        "licenseVolume": "25"
                    }
                ],
                "audio": [
                    {
                        "audioBroadcast": "false",
                        "callBack": "false",
                        "callBackInternational": "false",
                        "callinToll": "false",
                        "callinGlobal": "false",
                        "cloudConnectedAudio": "false",
                        "integratedVOIP": "false",
                        "sipInOut": "false",
                        "productName": "WX",
                        "serviceName": "TSP",
                        "action": "New",
                        "siteUrl": "Alightacademypoc.webex.com"
                    }
                ]
            }
        }
    }
]

