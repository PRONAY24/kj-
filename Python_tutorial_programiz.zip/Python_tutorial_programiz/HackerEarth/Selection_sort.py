array = [2,4,1,4,6,5,0]
def selection_sort(array):
    for i in range(0,len(array)-1):
        iMin = i
        for j in range(i+1,len(array)):
            if array[j] < array[iMin] :
                iMin = j
        array[i], array[iMin] = array[iMin], array[i]

selection_sort(array)
print(array)
