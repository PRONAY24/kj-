A0 = dict(zip((1,2,3,4,5),('a','b','c','d','e')))
A1 = range(10)
A2 = sorted([i for i in A1 if i in A0])
print(A2)