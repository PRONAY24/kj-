n = int(input())
strg =[]
for i in range(n):
    even = []
    odd = []
    value = input()
    strg.append(value)
    for j in range(len(strg[i])):
        if j%2 == 0:
            even.append(strg[i][j])
        else:
            odd.append(strg[i][j])
    print("".join(even),end=" ")
    print("".join(odd),end=" ")
    print()
