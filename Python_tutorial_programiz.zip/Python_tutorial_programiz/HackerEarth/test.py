def fib_gen():
    a, b = 1,1
    while 1:
        yield b
        a, b = a+1, a * b
fs = fib_gen()
print(next(fs))
print(next(fs))
print(next(fs))
print(next(fs))
print(next(fs))
for i in range(2):
    print(next(fs))