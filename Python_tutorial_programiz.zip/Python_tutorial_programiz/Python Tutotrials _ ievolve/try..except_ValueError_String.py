try :
    value = input()
    if len(value) > 10 :
        raise ValueError("More than 10 characters")

except ValueError as a :
    print(a)