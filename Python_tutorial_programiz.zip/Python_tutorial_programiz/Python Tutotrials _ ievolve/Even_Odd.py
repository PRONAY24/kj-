import itertools

n = [10, 13, 16, 22, 9, 4 , 37]
even =[]
odd = []
for i in n:
    if i%2 == 0:
        even.append(i)
    else:
        odd.append(i)

print(odd)
print(even)
