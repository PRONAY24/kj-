x = [1,2,4,5]

s = iter(x)
print(next(s))
print(next(s))
print(next(s))
print(next(s))