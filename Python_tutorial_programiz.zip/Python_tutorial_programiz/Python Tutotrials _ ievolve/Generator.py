x = [1,4,2,5]

y = (i**2 for i in x)
print(next(y))
print(next(y))
print(next(y))