def divide(a,b):

    try:

        result = a / b

        return result

    except ZeroDivisionError:

        print("Dividing by Zero.")

    finally:

        print("In finally clause.")

print('First call')

print(divide(14, 7))

print('Second call')

print(divide(14, 0))
