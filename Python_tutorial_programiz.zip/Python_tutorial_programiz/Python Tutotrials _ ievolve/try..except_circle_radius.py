class Circle:
    def __init__(self,radius):
        self.radius = radius

V1 = Circle("23")

try:
    if type(V1.radius) is not int:
        raise TypeError("RadiusInputError : {} is not a number".format(V1.radius))
except TypeError as a:
    print(a)

