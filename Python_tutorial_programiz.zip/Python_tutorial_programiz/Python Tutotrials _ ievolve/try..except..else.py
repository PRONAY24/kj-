try:

    a = 14 / 7

except ZeroDivisionError:

    print('oops!!!')

else:

    print('First ELSE')



try:

    a = 14 / 0

except ZeroDivisionError:

    print('oops!!!')

else:

    print('Second ELSE')