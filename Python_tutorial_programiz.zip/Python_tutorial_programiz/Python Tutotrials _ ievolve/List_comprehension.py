x = [1,2,4,5,6]

y = [i*2 for i in x]
print(y)