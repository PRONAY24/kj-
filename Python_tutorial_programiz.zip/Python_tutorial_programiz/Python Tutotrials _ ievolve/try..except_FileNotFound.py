import os

try :
    if os.path.exists("/Users/proprama/Desktop/VOIP.png") == False:
        raise FileNotFoundError("File Not found.")
    else:
        print("File Found..")
except FileNotFoundError as a :
    print(a)

