try :
    value = input()
    if value not in range(0, 100):
        raise ValueError("Value not in 0,100")

except ValueError as a :
    print(a)

