class CustomError(Exception):

    def __init__(self, value):

        self.value = value



    def __str__(self):

        return str(self.value)
try:

    a = 2; b = 'hello'

    if not (isinstance(a, int)

            and isinstance(b, int)):

        raise CustomError('Two inputs must be integers.')

    c = a**b

except CustomError as e:

    print(e)