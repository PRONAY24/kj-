from math import sqrt
def allFactors(self, A):
    L = []
    for i in range(1, int(sqrt(A)) + 1):
        if (A % i == 0):
            L.append(int(i))
            if (i != sqrt(A)):
                L.append(int(A / i))
    L.sort()
    return (L)