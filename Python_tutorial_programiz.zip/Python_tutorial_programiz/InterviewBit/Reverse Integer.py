def reverse(self, x):
    min_value = -2 ** 31
    max_value = 2 ** 31 - 1

    negative = False
    result = 0
    if x < 0:
        x = -x
        negative = True

    while x > 0:
        num = x % 10
        x = x // 10
        result = result * 10 + num

    if result > 2 ** 31 - 1:
        return 0
    if negative:
        result = -result
    return result