x = 5
for i in range(1,x+1):
    c = 1
    traingle = []
    for j in range(1,i+1):
        print(c,end=" ")
        traingle.append(c)
        c = int(c*(i-j)/j)
    print()
