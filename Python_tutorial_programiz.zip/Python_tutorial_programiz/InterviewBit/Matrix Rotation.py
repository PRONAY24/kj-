#Rotate the matrix
'''
Input

1 2 3  [0,0] [0,1] [0,2]  3 6 9  [0,2] [1,2] [2,2]
4 5 6  [1,0] [1,1] [1,2]  2 5 8  [0,1] [1,1] [2,1]
7 8 9  [2,0] [2,1] [2,2]  1 4 7  [0,0] [1,0] [2,0

Output

3 6 9
2 5 8
1 4 7
'''

A = [[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16]]
B =[]
def roateMatrix(A):
    r = len(A)-1
    c = len(A[0])
    for i in range(r,-1,-1):
        li = []
        for j in range(c):
            li.append(A[j][i])
            print(A[j][i],end=" ")
            #print(li)
        B.append(li)
        print()
    print(B)
roateMatrix(A)