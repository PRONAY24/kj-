'''
Sample Input

4
aba
baba
aba
xzxb
3
aba
xzxb
ab
Sample Output

2
1
0
'''

n = int(input())
li = []
for i in range(n):
    x = input()
    li.append(x)
nquery = int(input())
for i in range(nquery):
    y = input()
    if y in li:
        print(li.count(y))
    else:
        print(0)