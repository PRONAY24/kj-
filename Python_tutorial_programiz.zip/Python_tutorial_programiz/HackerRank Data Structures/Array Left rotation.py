'''
5 4
1 2 3 4 5
5 1 2 3 4
'''


#n,d = input().split(" ")
#n = int(n)
#d = int(d)
#arr = [int(x) for x in input().split(" ")]

arr = list(map(int,input().split()))
d = int(input())
d = d%len(arr)
temp = arr[d:]
for i in range(d):
    temp.append(arr[i])
print(*temp)