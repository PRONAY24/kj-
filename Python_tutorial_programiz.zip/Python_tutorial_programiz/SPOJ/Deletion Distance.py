def deletion_distance(word1, word2):
    # create an empty dictionary
    charMap = {}

    # loop through all letters in word1, count the frequency of each
    for c in word1:
        if c in charMap:
            charMap[c] = charMap[c] + 1
        else:
            charMap[c] = 1

    deletions = 0

    # match with the letters in word2
    for c in word2:
        if c in charMap:
            if charMap[c] > 0:  # common letters
                charMap[c] = charMap[c] - 1
            else:  # count mismatch
                deletions = deletions + 1
        else:
            deletions = deletions + 1  # present only in word2

    # If there are more characters in first word, delete them
    for c in charMap:
        if charMap[c] > 0:
            deletions = deletions + charMap[c]

    print(deletions)



a = input()
b = input()
deletion_distance(a,b)

