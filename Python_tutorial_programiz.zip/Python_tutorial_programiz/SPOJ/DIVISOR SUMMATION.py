import math
n = int(input())
for i in range(n):
    x = int(input())
    sum = 0
    for i in range(2,int(math.sqrt(x))+1):
        if x%i == 0:
            if i == (x//i):
                sum += i
            else:
                sum = sum + (i + x//i)
    if x <= 1:
        print(sum)
    else:
        print(sum+1)
