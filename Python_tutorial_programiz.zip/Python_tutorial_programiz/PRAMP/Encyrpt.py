st = input()
asc_val = 1
for i in st:
    x = ord(i)
    asc_val += x
    while asc_val <= ord('a') or asc_val >= ord('z'):
        asc_val = asc_val - 26
    print(chr(asc_val),end="")